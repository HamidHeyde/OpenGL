#version 410

in vec4 dstColor;
out vec4 finalcolor;

void main(){
finalcolor = dstColor;
}
